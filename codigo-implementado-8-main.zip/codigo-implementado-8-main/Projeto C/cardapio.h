#include <stdio.h>

void cardapio(){
    printf("\n======== CARDAPIO ========\n");
    printf("\n======== COMIDAS =========\n");
    printf("1. Pastel de carne / R$ 8\n");
    printf("3. Pastel de pizza / R$ 8\n");
    printf("4. Coxinha de carne / R$ 6\n");
    printf("5. Coxinha de frango / R$ 6\n");
    printf("6. Coxinha de calabresa / R$ 6\n");
    printf("7. Espetinho de coracao de galinha / RS 8\n");
    printf("8. Espetinho de carne de gado / RS 8\n");
    printf("9. Porcao de Batata frita + Cheddar + Bacon / R$ 18\n");
    printf("10. X Salada / R$ 18\n");
    printf("11. X Bacon / R$ 20\n");
    printf("12. X Frango / R$ 25\n");
    printf("13. X Burguer / R$ 16\n");
    printf("\n======== BEBIDAS =========\n");
    printf("14. Copo de cafe com acucar / R$ 1\n");
    printf("15. Copo de cafe sem acucar / R$ 1\n");
    printf("16. Copo de cafe com Leite / R$ 2\n");
    printf("17. Coca-cola lata 350ml / R$ 5\n");
    printf("18. Guarana lata 350ml / R$ 5\n");
    printf("19. Sprite lata 350ml / R$ 4\n");


}