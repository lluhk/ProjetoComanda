#include <stdio.h>
#include "estrutura.h"

void removerPedidos() {
    if (numPedidos == 0) {
        printf("\nNenhum pedido em andamento para remover.\n");
    } else {
        int pedidoRemover;
        printf("\nQual o numero do pedido que deseja remover?\n");
        scanf("%d", &pedidoRemover);

        if (pedidoRemover > 0 && pedidoRemover <= numPedidos) {
            pedidosRemovidos[numPedidosRemovidos] = pedidos[pedidoRemover - 1];
            numPedidosRemovidos++;

            for (int i = pedidoRemover - 1; i < numPedidos - 1; i++) {
                pedidos[i] = pedidos[i + 1];
            }
            numPedidos--;

            printf("\nPedido %d removido com sucesso.\n", pedidoRemover);
        } else {
            printf("\nNumero do pedido invalido.\n");
        }
    }
}
