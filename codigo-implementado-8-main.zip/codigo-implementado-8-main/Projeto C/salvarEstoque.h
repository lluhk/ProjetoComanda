#include <stdio.h>
#include "estrutura.h"

void salvarEstoque(Produto estoque[], int numProdutos) {
    FILE *file = fopen("estoque.txt", "w");
    if (file == NULL) {
        printf("Erro ao abrir o arquivo para salvar.\n");
        return;
    }

    for (int i = 0; i < numProdutos; i++) {
        fprintf(file, "%d %s %d\n", estoque[i].produtoCodigo, estoque[i].nome, estoque[i].quantidade);
    }

    fclose(file);
    printf("Estoque salvo com sucesso!\n");
}
