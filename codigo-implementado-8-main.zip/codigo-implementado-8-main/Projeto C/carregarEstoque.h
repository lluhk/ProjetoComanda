#include <stdio.h>
#include "estrutura.h"

void carregarEstoque(Produto estoque[], int *numProdutos) {
    FILE *file = fopen("estoque.txt", "r");
    if (file == NULL) {
        printf("Erro ao abrir o arquivo para carregar.\n");
        return;
    }

    *numProdutos = 0;
    while (fscanf(file, "%d %s %d", &estoque[*numProdutos].produtoCodigo, estoque[*numProdutos].nome, &estoque[*numProdutos].quantidade) != EOF) {
        (*numProdutos)++;
    }

    fclose(file);
    printf("Estoque carregado com sucesso!\n");
}
