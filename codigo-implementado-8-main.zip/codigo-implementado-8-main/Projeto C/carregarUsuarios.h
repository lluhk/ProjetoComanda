#include <stdio.h>
#include <string.h>
#include "estrutura.h"

void carregarUsuarios() {
    FILE *file = fopen("usuarios.txt", "r");
    if (file == NULL) {
        printf("Erro ao abrir o arquivo para carregar usuarios.\n");
        return;
    }

    numUsuarios = 0;
    while (fscanf(file, "%s %s %d", usuarios[numUsuarios].nome, usuarios[numUsuarios].senha, &usuarios[numUsuarios].nivelAcesso) != EOF) {
        numUsuarios++;
    }

    fclose(file);
    printf("Usuarios carregados com sucesso!\n");
}
