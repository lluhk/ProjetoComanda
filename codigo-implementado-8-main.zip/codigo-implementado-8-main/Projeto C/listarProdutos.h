#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "estrutura.h"

void listarProdutos(Produto estoque[], int numProdutos) {
    system("cls");
    printf("\nLista de Produtos no Estoque:\n");
    for (int i = 0; i < numProdutos; i++) {
        printf("\nID: %d, \nNome: %s, \nQuantidade: %d\n", estoque[i].produtoCodigo, estoque[i].nome, estoque[i].quantidade);
    }
}
