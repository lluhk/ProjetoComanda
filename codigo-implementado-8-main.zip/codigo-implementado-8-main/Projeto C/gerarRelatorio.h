#include <stdio.h>
#include <string.h>
#include "estrutura.h"

typedef struct {
    int codigoProduto;
    int quantidadeVendida;
} RelatorioProduto;

void gerarRelatorio() {
    int totalGanho = 0;
    int produtoVendas[MAX_PRODUTOS] = {0};

    for (int i = 0; i < numPedidos; i++) {
        totalGanho += pedidos[i].valorTotal;
        for (int j = 0; j < pedidos[i].numItems; j++) {
            produtoVendas[pedidos[i].items[j].produtoCodigo] += pedidos[i].items[j].quantidade;
        }
    }

    for (int i = 0; i < numPedidosRemovidos; i++) {
        totalGanho += pedidosRemovidos[i].valorTotal;
        for (int j = 0; j < pedidosRemovidos[i].numItems; j++) {
            produtoVendas[pedidosRemovidos[i].items[j].produtoCodigo] += pedidosRemovidos[i].items[j].quantidade;
        }
    }

    RelatorioProduto relatorio[MAX_PRODUTOS];
    int numProdutosVendidos = 0;

    for (int i = 0; i < MAX_PRODUTOS; i++) {
        if (produtoVendas[i] > 0) {
            relatorio[numProdutosVendidos].codigoProduto = i;
            relatorio[numProdutosVendidos].quantidadeVendida = produtoVendas[i];
            numProdutosVendidos++;
        }
    }

    for (int i = 0; i < numProdutosVendidos - 1; i++) {
        for (int j = i + 1; j < numProdutosVendidos; j++) {
            if (relatorio[i].quantidadeVendida < relatorio[j].quantidadeVendida) {
                RelatorioProduto temp = relatorio[i];
                relatorio[i] = relatorio[j];
                relatorio[j] = temp;
            }
        }
    }

    printf("\n======== RELATORIO DE VENDAS ========\n");
    printf("\nValor Total Ganhado: R$ %d,00\n", totalGanho);
    printf("\nProdutos mais vendidos:\n");
    for (int i = 0; i < numProdutosVendidos; i++) {
        printf("Codigo do Produto: %d, Quantidade Vendida: %d\n", relatorio[i].codigoProduto, relatorio[i].quantidadeVendida);
    }
    printf("\n=====================================\n");
}
