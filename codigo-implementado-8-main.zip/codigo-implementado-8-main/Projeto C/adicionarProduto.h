#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "estrutura.h"

void adicionarProduto(Produto estoque[], int *numProdutos) {
    if (*numProdutos >= MAX_PRODUTOS) {
        printf("\nErro: O estoque esta cheio!\n");
        return;
    }

    printf("\nDigite o nome do produto: ");
    scanf("%s", estoque[*numProdutos].nome);
    printf("\nDigite a quantidade do produto: ");
    scanf("%d", &estoque[*numProdutos].quantidade);

    estoque[*numProdutos].produtoCodigo = *numProdutos + 1;

    (*numProdutos)++;

    printf("\nProduto adicionado ao estoque com sucesso!\n");
}
