#include <stdio.h>
#include "estrutura.h"

void salvarUsuarios() {
    FILE *file = fopen("usuarios.txt", "w");
    if (file == NULL) {
        printf("Erro ao abrir o arquivo para salvar usuarios.\n");
        return;
    }

    for (int i = 0; i < numUsuarios; i++) {
        fprintf(file, "%s %s %d\n", usuarios[i].nome, usuarios[i].senha, usuarios[i].nivelAcesso);
    }

    fclose(file);
    printf("Usuarios salvos com sucesso!\n");
}
