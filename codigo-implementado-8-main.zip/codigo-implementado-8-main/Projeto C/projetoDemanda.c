#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "estrutura.h"
#include "adicionarProduto.h"
#include "retirarProduto.h"
#include "listarProdutos.h"
#include "cardapio.h"
#include "agendamentoPedidos.h"
#include "consultarPedidos.h"
#include "gerarRelatorio.h"
#include "removerPedidos.h"
#include "carregarUsuarios.h"
#include "salvarUsuarios.h"
#include "carregarEstoque.h"
#include "salvarEstoque.h"

Usuario usuarios[MAX_USUARIOS];
int numUsuarios = 0;

int login(char *usuario, char *senha)
{
    for (int i = 0; i < numUsuarios; i++)
    {
        if (strcmp(usuarios[i].nome, usuario) == 0 && strcmp(usuarios[i].senha, senha) == 0)
        {
            return usuarios[i].nivelAcesso;
        }
    }
    return -1; 
}

void cadastrarUsuario()
{
    if (numUsuarios >= MAX_USUARIOS)
    {
        printf("\nErro: Limite de usuarios atingido!\n");
        return;
    }

    printf("\nDigite o nome do novo usuario: ");
    scanf("%s", usuarios[numUsuarios].nome);
    printf("Digite a senha do novo usuario: ");
    scanf("%s", usuarios[numUsuarios].senha);
    printf("Digite o nivel de acesso (0 = funcionario, 1 = administrador): ");
    scanf("%d", &usuarios[numUsuarios].nivelAcesso);

    numUsuarios++;
    salvarUsuarios();
    printf("\nUsuario cadastrado com sucesso!\n");
}

int main()
{
    int senha, entrada, entrada1, entrada2, quantidade, valorTotal, opcao, numProdutos = 0, estoque[MAX_PRODUTOS][MAX_ATRIBUTOS];
    carregarUsuarios(); 
    carregarEstoque(estoque, &numProdutos);
    

    for (int sent = 1; sent == 1;)
    {
        printf("\n======== MENU LOGIN ========\n");
        printf("\n1. Login\n");
        printf("2. Cadastrar Usuario\n");
        printf("0. Sair\n");
        scanf("%i", &entrada);

        if (entrada == 1)
        {
            char usuario[15], senha[15];
            int nivelAcesso;

            printf("\nDigite o nome de usuario:\n");
            scanf("%s", usuario);
            printf("\nDigite a senha:\n");
            scanf("%s", senha);

            nivelAcesso = login(usuario, senha);

            if (nivelAcesso == -1)
            {
                printf("\nUsuario ou senha incorretos! Tente novamente.\n");
            }
            else
            {
                printf("\nLogin bem sucedido!\n");

                for (int sent2 = 1; sent2 == 1;)
                {
                    printf("\n======== MENU PRINCIPAL ========\n");
                    printf("1. Agendamento de pedidos\n");
                    printf("2. Gerenciamento de estoque\n");
                    printf("3. Gerar Relatorio de Vendas\n");
                    printf("0. Sair\n");
                    scanf("%i", &entrada1);

                    if (entrada1 == 1)
                    {
                        for (int sent3 = 1; sent3 == 1;)
                        {
                            printf("\n======== MENU ========\n");
                            printf("1. Cardapio\n");
                            printf("2. Agendar pedido\n");
                            printf("3. Consultar pedidos em andamento\n");
                            printf("4. Concluir Pedidos\n");
                            printf("0. Sair\n");
                            scanf("%i", &entrada2);

                            if (entrada2 == 1)
                            {
                                cardapio();
                            }
                            else if (entrada2 == 2)
                            {
                                cardapio();
                                valorTotal = 0;

                                printf("\nQuantos produtos voce deseja agendar?\n");
                                scanf("%i", &quantidade);
                                agendamentoPedidos(quantidade, valorTotal);
                            }
                            else if (entrada2 == 3)
                            {
                                consultarPedidos();
                            }
                            else if (entrada2 == 4)
                            {
                                removerPedidos();
                            }
                            else if (entrada2 == 0)
                            {
                                sent3 = 0;
                                break;
                            }
                            else
                            {
                                printf("\nOpcao invalida!\n");
                            }
                        }
                    }
                    else if (entrada1 == 2)
                    {
                        do
                        {
                            printf("\n===== MENU =====\n");
                            printf("1. Adicionar Produto\n");
                            printf("2. Retirar Produto\n");
                            printf("3. Listar Produtos\n");
                            printf("0. Sair\n");
                            printf("Digite sua opcao: ");
                            scanf("%d", &opcao);

                            switch (opcao)
                            {
                            case 1:
                                adicionarProduto(estoque, &numProdutos);
                                break;
                            case 2:
                                retirarProduto(estoque, &numProdutos);
                                break;
                            case 3:
                                listarProdutos(estoque, numProdutos);
                                break;
                            case 0:
                                break;
                            default:
                                printf("\nOpcao invalida!\n");
                            }
                        } while (opcao != 0);
                    }
                    else if (entrada1 == 3)
                    {
                        gerarRelatorio();
                    }
                    else if (entrada1 == 0)
                    {
                        printf("\n======== Voce saiu! ========\n");
                        sent = 0;
                        sent2 = 0;
                        break;
                    }
                    else
                    {
                        printf("\nOpcao invalida!\n");
                    }
                }
            }
        }
        else if (entrada==2)
        {
            cadastrarUsuario();
        }
        
        else if (entrada == 0)
        {
            printf("\n======== Voce saiu! ========\n");
            sent = 0;
        }
        else
        {
            printf("\nDigite uma opcao valida!\n");
        }
    }
    salvarEstoque(estoque, numProdutos);

    return 0;
}
