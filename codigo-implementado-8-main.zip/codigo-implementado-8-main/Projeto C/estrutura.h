// estrutura.h

#ifndef ESTRUTURA_H
#define ESTRUTURA_H

#define MAX_NOME 50
#define MAX_USUARIOS 100
#define MAX_PRODUTOS 100
#define MAX_ATRIBUTOS 100
#define MAX_PEDIDOS 50
#define MAX_ITEMS 10

typedef struct {
    int codigo;
    char nome[MAX_NOME];
    int quantidade;
    float preco;
    int produtoCodigo;
} Produto;

typedef struct {
    char nome[MAX_NOME];
    char senha[MAX_NOME];
    int nivelAcesso; // 0 = funcionário, 1 = administrador
} Usuario;

typedef struct {
    int produtoCodigo;
    int quantidade;
} Item;

#define MAX_REMOVED_PEDIDOS 50

typedef struct {
    Item items[MAX_ITEMS];
    int numItems;
    int valorTotal;
    int horarioRetirada;
} Pedido;

extern Usuario usuarios[MAX_USUARIOS];
extern int numUsuarios;

extern Produto estoque[MAX_PRODUTOS];
extern Pedido pedidos[MAX_PEDIDOS];
extern Pedido pedidosRemovidos[MAX_REMOVED_PEDIDOS];
extern int numPedidos;
extern int numPedidosRemovidos;

#endif